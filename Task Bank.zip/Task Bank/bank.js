var balance=0;

let input_dp=document.getElementById("depositAmount");
let  btn_dp=document.getElementById("btn_depo");

btn_dp.addEventListener("click",btn_deposit);

function btn_deposit(){
    balance+=Number(input_dp.value);
    alert("deposit success...");
    
    
}



let input_wi=document.getElementById("withdrawAmount");
let btn_wi=document.getElementById("btn_withdraw");

btn_wi.addEventListener("click",input_withdraw);

function input_withdraw(){
    balance-=Number(input_wi.value);
}

let but_check=document.getElementById("check_btn");
let display=document.getElementById("balanceDisplay");

but_check.addEventListener("click",show);

function show(){
    display.textContent=balance;
}





